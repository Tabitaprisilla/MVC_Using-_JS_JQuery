﻿using C_Sharp_Access_Modifiers;
using C_Sharp_Coding;
using System.Numerics;

namespace Method_Overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Tutorial T1 = new Tutorial();
            T1.setTutorial(1, "True IQ Tutorials");
            Console.WriteLine($"Tutorial Id: {T1.GetTutorailID()}");
            Console.WriteLine($"Tutorial Name: {T1.GetTutorialName()}");
            T1.TutorialId = 2;
            T1.TutorialName = "Study Point";
            Console.WriteLine($"Tutorial Id: {T1.GetTutorailID()}");
            Console.WriteLine($"Tutorial Name: {T1.GetTutorialName()}");


            Infotech_Tutorial IT = new Infotech_Tutorial();
            IT.Renametutorial("Great Learner Center");
            IT.TutorialId = 3;
            Console.WriteLine($"New Tutorial Id: {IT.GetTutorailID()}");
            Console.WriteLine($"New Tutorial Name: {IT.GetTutorialName()}");

            //Method Overloading(Static Polymorphism/ Compile time Polymorphism)
            Addition A1 = new Addition();
            int Sum1 = A1.PlusMethod(5, 6);
            Console.WriteLine("Integer Sum1:" + Sum1);
            double Sum2 = A1.PlusMethod(78.99, 67.88);
            Console.WriteLine("Double Sum2:" + Sum2);
            int Sum3 = A1.PlusMethod(4, 6, 7);
            Console.WriteLine("Integer Sum3: " + Sum3);


        }
    }
}

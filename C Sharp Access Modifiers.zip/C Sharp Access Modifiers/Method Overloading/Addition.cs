﻿namespace C_Sharp_Coding
{
     class Addition
    {

        //Method Overloading (Static Polymorphism/ Compile time Polymorphism)
        public int PlusMethod(int x, int y)
        {
            return x + y;
        }

        public int PlusMethod(int x, int y, int z)
        {
            return x + y + z;
        }

        public double PlusMethod(double y, double x)
        {
            return x + y;
        }
    }
}

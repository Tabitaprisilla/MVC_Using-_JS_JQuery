﻿namespace C_Sharp_Access_Modifiers
{
    class Program
    {
        static void Main(string[] args)
        {
            Tutorial T1 = new Tutorial();
            T1.setTutorial(1, "True IQ Tutorials");
            Console.WriteLine($"Tutorial Id: {T1.GetTutorailID()}");
            Console.WriteLine($"Tutorial Name: {T1.GetTutorialName()}");
            T1.TutorialId = 2;
            T1.TutorialName = "Study Point";
            Console.WriteLine($"Tutorial Id: {T1.GetTutorailID()}");
            Console.WriteLine($"Tutorial Name: {T1.GetTutorialName()}");


            Infotech_Tutorial I1 = new Infotech_Tutorial();
            I1.Renametutorial("Great Learner Center");
            I1.TutorialId = 3;
            Console.WriteLine($"New Tutorial Id: {I1.GetTutorailID()}");
            Console.WriteLine($"New Tutorial Name: {I1.GetTutorialName()}");


            //Method Overriding(Dynamic Polymorphism/ Run time Polymorphism)

            Tutorial T2 = new Tutorial();
            Tutorial I2 = new Infotech_Tutorial();
            T2.tutorialdetails("Mainframe", 15000.00);
            I2.tutorialdetails("C#", 1700.00);



        }
    }
}

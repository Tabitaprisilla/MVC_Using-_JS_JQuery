﻿using System.Runtime.InteropServices;

namespace C_Sharp_Access_Modifiers
{
    public class Infotech_Tutorial : Tutorial
    {
        public void Renametutorial(string PNewName)
        {
            TutorialName = PNewName;

        }

        public override void tutorialdetails(string course, double fees)
        {
            Console.WriteLine("infotech tutorial start first batch in month of june");
            Console.WriteLine($"course:{course} \nfee amount:{fees}");
        }

    }
}

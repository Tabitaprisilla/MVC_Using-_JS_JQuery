﻿using System.Security.Cryptography.X509Certificates;

namespace C_Sharp_Access_Modifiers
{
    public class Tutorial
    {

        public int TutorialId;
        public string TutorialName;

        public void setTutorial(int pid, string pname)
        {
            TutorialId = pid;
            TutorialName = pname;
        }
        public String GetTutorialName()
        {
            return TutorialName;
        }

        public int GetTutorailID()
        {
            return TutorialId;
        }


        public virtual void tutorialdetails(string course, double fees)
        {
            Console.WriteLine("general tutorial start first batch in month of march");
            Console.WriteLine($"course:{course} \nfee amount:{fees}");

        }





    }
}
